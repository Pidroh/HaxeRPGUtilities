# Generic RPG Idle I

### [Play here!](https://pidroh.github.io/GenericRPGIdle/)

### [Roadmap](https://github.com/Pidroh/HaxeRPGUtilities/wiki)

### [Discord Channel](https://discord.com/invite/AtGrxpM)

### What is Generic RPG Idle I?
This is a prototype for the progression mechanics that I want to implement in [Brave Ball](https://store.steampowered.com/app/1638970/Brave_Ball/).
Brave Ball is an action RPG that you fight using a soccer ball. Wishlist now to know when it launches!
